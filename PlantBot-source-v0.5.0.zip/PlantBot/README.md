# Plant’Bot

Application Android de gestion partagée des plantes de Yanick et Jessica.

## Version 0.5.0

- interface responsive pour écran externe et grand écran pliable ;
- mascotte animée et humidité clairement indiquée comme estimation ;
- fiches préchargées pour les plantes du foyer ;
- saisie des arrosages en décilitres et historique local ;
- ajout de plantes et rappels Android quotidiens ;
- synchronisation Firebase entre Yanick et Jessica, y compris les photos ;
- descriptions et conseils générés avec Firebase AI Logic et Gemini ;
- compilation et signature permanente de l’APK avec GitHub Actions.

L’IA produit des conseils indicatifs : l’identification et les besoins réels de chaque plante doivent rester vérifiés.
