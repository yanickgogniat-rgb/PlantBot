package ch.yanick.plantbot

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.BitmapFactory
import android.util.Base64
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.work.*
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch

private val Green = Color(0xFF188A68)
private val DarkGreen = Color(0xFF103C32)
private val Cream = Color(0xFFF6F7F0)
private val SoftGreen = Color(0xFFDCEEDB)
private val Orange = Color(0xFFFF6B35)
private const val HOUSEHOLD_ID = "yanick-jessica"
private const val YANICK_UID = "eOJpV4U9F3XJJ7O4OGkLd41ZeqY2"
private const val JESSICA_UID = "tG1yO0fD1SUkSLKUzmYIrSPpSJn2"

private enum class AppScreen { HOME, REMINDERS, SETTINGS }

data class Plant(
    val id: Long,
    val name: String,
    val species: String,
    val intervalDays: Int,
    val lastWatered: Long,
    val lastAmountDl: Int,
    val photoUri: String = "",
    val description: String = ""
) {
    val daysSinceWatered: Int get() = ((System.currentTimeMillis() - lastWatered) / 86_400_000L).toInt().coerceAtLeast(0)
    val moisture: Int get() = (100 - daysSinceWatered * (100 / intervalDays.coerceAtLeast(1))).coerceIn(0, 100)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        scheduleChecks()
        setContent { PlantBotApp(PlantStore(this)) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("watering", "Rappels d’arrosage", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun scheduleChecks() {
        val request = PeriodicWorkRequestBuilder<WateringWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("plant-check", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}

class WateringWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val store = PlantStore(applicationContext)
        if (!store.notificationsEnabled()) return Result.success()
        val due = store.load().filter { it.daysSinceWatered >= it.intervalDays }
        if (due.isNotEmpty()) {
            val notification = NotificationCompat.Builder(applicationContext, "watering")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Plant’Bot a besoin de toi 💧")
                .setContentText("${due.first().name} est à vérifier${if (due.size > 1) " et ${due.size - 1} autre(s) plante(s)" else ""}.")
                .setAutoCancel(true)
                .build()
            applicationContext.getSystemService(NotificationManager::class.java).notify(1001, notification)
        }
        return Result.success()
    }
}

class PlantStore(context: Context) {
    private val prefs = context.getSharedPreferences("plants", Context.MODE_PRIVATE)
    fun load(): List<Plant> {
        val raw = prefs.getString("items", null) ?: return defaults().also(::save)
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { i ->
                val o = array.getJSONObject(i)
                Plant(o.getLong("id"), o.getString("name"), o.optString("species"), o.getInt("interval"), o.getLong("watered"), o.getInt("amount"), o.optString("photoUri"), o.optString("description"))
            }
        }.getOrElse { defaults() }
    }
    fun save(plants: List<Plant>) {
        val a = JSONArray()
        plants.forEach { p -> a.put(JSONObject().apply {
            put("id", p.id); put("name", p.name); put("species", p.species); put("interval", p.intervalDays)
            put("watered", p.lastWatered); put("amount", p.lastAmountDl)
            put("photoUri", p.photoUri); put("description", p.description)
        }) }
        prefs.edit().putString("items", a.toString()).apply()
    }
    fun notificationsEnabled() = prefs.getBoolean("notifications", true)
    fun setNotificationsEnabled(enabled: Boolean) = prefs.edit().putBoolean("notifications", enabled).apply()
    private fun defaults(): List<Plant> {
        val now = System.currentTimeMillis()
        return listOf(
            Plant(1, "Alocasia", "Alocasia", 6, now - 5 * 86_400_000L, 3),
            Plant(2, "Caladium", "Caladium bicolor", 4, now - 2 * 86_400_000L, 3),
            Plant(3, "Aglaonema argenté", "Aglaonema", 8, now - 3 * 86_400_000L, 3),
            Plant(4, "Croton ‘Iceton’", "Codiaeum variegatum", 6, now - 3 * 86_400_000L, 3),
            Plant(5, "Euphorbia platyclada", "Euphorbia", 14, now - 7 * 86_400_000L, 2)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlantBotApp(store: PlantStore) {
    var plants by remember { mutableStateOf(store.load()) }
    var syncStatus by remember { mutableStateOf("Connexion requise") }
    var watering by remember { mutableStateOf<Plant?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var selectedPlant by remember { mutableStateOf<Plant?>(null) }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val firestore = remember { FirebaseFirestore.getInstance() }
    var cloudListener by remember { mutableStateOf<ListenerRegistration?>(null) }
    fun canSync() = FirebaseAuth.getInstance().currentUser?.uid in setOf(YANICK_UID, JESSICA_UID)
    fun saveCloud(plant: Plant) {
        if (!canSync()) return
        firestore.collection("households").document(HOUSEHOLD_ID).collection("plants").document(plant.id.toString())
            .set(mapOf("id" to plant.id, "name" to plant.name, "species" to plant.species, "intervalDays" to plant.intervalDays, "lastWatered" to plant.lastWatered, "lastAmountDl" to plant.lastAmountDl, "description" to plant.description, "photoData" to plant.photoUri.takeIf { it.startsWith("data:image/") }.orEmpty()))
    }
    fun deleteCloud(plant: Plant) {
        if (canSync()) firestore.collection("households").document(HOUSEHOLD_ID).collection("plants").document(plant.id.toString()).delete()
    }
    DisposableEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        val authListener = FirebaseAuth.AuthStateListener { currentAuth ->
            cloudListener?.remove(); cloudListener = null
            val user = currentAuth.currentUser
            if (user == null) { syncStatus = "Connexion requise"; return@AuthStateListener }
            if (user.uid !in setOf(YANICK_UID, JESSICA_UID)) { syncStatus = "Compte non autorisé"; return@AuthStateListener }
            syncStatus = "Synchronisation…"
            val collection = firestore.collection("households").document(HOUSEHOLD_ID).collection("plants")
            var initialHandled = false
            cloudListener = collection.addSnapshotListener { snapshot, error ->
                if (error != null) { syncStatus = "Erreur de synchronisation"; return@addSnapshotListener }
                val documents = snapshot?.documents.orEmpty()
                if (!initialHandled && documents.isEmpty() && user.uid == YANICK_UID) {
                    initialHandled = true
                    plants.forEach(::saveCloud)
                    syncStatus = "Envoi des plantes…"
                } else if (documents.isNotEmpty()) {
                    initialHandled = true
                    val localPhotos = plants.associate { it.id to it.photoUri }
                    plants = documents.mapNotNull { d -> runCatching {
                        val id = d.getLong("id") ?: d.id.toLong()
                        val photo = if (d.contains("photoData")) d.getString("photoData").orEmpty() else localPhotos[id].orEmpty()
                        Plant(id, d.getString("name").orEmpty(), d.getString("species").orEmpty(), (d.getLong("intervalDays") ?: 7).toInt(), d.getLong("lastWatered") ?: System.currentTimeMillis(), (d.getLong("lastAmountDl") ?: 0).toInt(), photo, d.getString("description").orEmpty())
                    }.getOrNull() }.sortedBy { it.id }
                    store.save(plants); syncStatus = "Synchronisé avec le foyer"
                } else if (user.uid == JESSICA_UID) syncStatus = "En attente des plantes de Yanick"
            }
        }
        auth.addAuthStateListener(authListener)
        onDispose { auth.removeAuthStateListener(authListener); cloudListener?.remove() }
    }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Cream, surface = Color.White, onBackground = DarkGreen)) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = {
                if (screen == AppScreen.HOME) FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Color.White) { Icon(Icons.Rounded.Add, "Ajouter") }
            },
            bottomBar = { BottomBar(screen) { screen = it } }
        ) { padding ->
            when (screen) {
                AppScreen.HOME -> BoxWithConstraints(Modifier.padding(padding).fillMaxSize()) {
                    val columns = if (maxWidth >= 600.dp) 2 else 1
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columns),
                        contentPadding = PaddingValues(18.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) { Header() }
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) {
                            val priority = plants.minByOrNull { it.moisture }
                            MascotCard(priority, onWater = { priority?.let { watering = it } })
                        }
                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) {
                            Text("Mes plantes", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.padding(top = 8.dp))
                        }
                        items(plants, key = { it.id }) { plant -> PlantCard(plant) { selectedPlant = plant } }
                    }
                }
                AppScreen.REMINDERS -> RemindersScreen(plants, Modifier.padding(padding)) { watering = it }
                AppScreen.SETTINGS -> SettingsScreen(store, syncStatus, Modifier.padding(padding))
            }
        }
        watering?.let { plant -> WaterDialog(plant, onDismiss = { watering = null }) { amount ->
            plants = plants.map { if (it.id == plant.id) it.copy(lastWatered = System.currentTimeMillis(), lastAmountDl = amount) else it }
            store.save(plants); plants.firstOrNull { it.id == plant.id }?.let(::saveCloud); watering = null
        } }
        if (showAdd) AddPlantDialog(onDismiss = { showAdd = false }) { name, species, days ->
            plants = plants + Plant(System.currentTimeMillis(), name, species, days, System.currentTimeMillis(), 0)
            store.save(plants); plants.lastOrNull()?.let(::saveCloud); showAdd = false
        }
        selectedPlant?.let { selected ->
            val current = plants.firstOrNull { it.id == selected.id }
            if (current != null) PlantDetailsDialog(
                plant = current,
                onDismiss = { selectedPlant = null },
                onWater = { selectedPlant = null; watering = current },
                onSave = { updated ->
                    plants = plants.map { if (it.id == updated.id) updated else it }
                    store.save(plants); saveCloud(updated); selectedPlant = updated
                },
                onDelete = {
                    plants = plants.filterNot { it.id == current.id }
                    store.save(plants); deleteCloud(current); selectedPlant = null
                }
            )
        }
    }
}

@Composable private fun Header() {
    Column { Text("Plant’Bot", color = Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); Text("Bonjour Yanick 👋", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = DarkGreen); Text("Comment vont vos plantes ?", color = Color(0xFF52625D), fontSize = 17.sp) }
}

@Composable private fun MascotCard(priority: Plant?, onWater: () -> Unit) {
    val moisture = priority?.moisture ?: 100
    val mascotImage = when {
        moisture < 30 -> ch.yanick.plantbot.R.drawable.plant_mascot_thirsty
        moisture <= 60 -> ch.yanick.plantbot.R.drawable.plant_mascot_calm
        else -> ch.yanick.plantbot.R.drawable.plant_mascot
    }
    val mascotMessage = when {
        moisture < 30 -> "J’ai soif…"
        moisture <= 60 -> "Je vais bien"
        else -> "Tout va bien !"
    }
    val transition = rememberInfiniteTransition(label = "robot")
    val bob by transition.animateFloat(-5f, 5f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "bob")
    Card(colors = CardDefaults.cardColors(containerColor = SoftGreen), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(0.9f).graphicsLayer { translationY = bob }) {
                Image(painter = painterResource(mascotImage), contentDescription = "Mascotte Plant’Bot", modifier = Modifier.size(128.dp))
                Text(mascotMessage, fontWeight = FontWeight.Bold, color = Green)
            }
            Column(Modifier.weight(1.2f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Humidité estimée", color = DarkGreen)
                Text("$moisture %", fontSize = 38.sp, fontWeight = FontWeight.Black, color = DarkGreen)
                Text(priority?.name ?: "Aucune plante", maxLines = 1, color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onWater, shape = RoundedCornerShape(18.dp)) { Text("J’ai arrosé") }
            }
        }
    }
}

@Composable private fun PlantCard(plant: Plant, onOpen: () -> Unit) {
    val alert = plant.daysSinceWatered >= plant.intervalDays
    Card(onClick = onOpen, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(if (alert) Color(0xFFFFE1D7) else SoftGreen), contentAlignment = Alignment.Center) {
                    if (plant.photoUri.isNotBlank()) PlantPhoto(plant.photoUri, "Photo de ${plant.name}", Modifier.fillMaxSize())
                    else Text(if (alert) "🪴" else "🌿", fontSize = 29.sp)
                }
                Spacer(Modifier.width(12.dp)); Column { Text(plant.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = DarkGreen); Text(plant.species, fontSize = 13.sp, color = Color.Gray) }
            }
            Spacer(Modifier.height(15.dp)); LinearProgressIndicator(progress = { plant.moisture / 100f }, modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape), color = if (alert) Orange else Green, trackColor = Color(0xFFE8ECE8))
            Spacer(Modifier.height(9.dp)); Text(if (alert) "💧 À vérifier aujourd’hui" else "💧 Humidité estimée ${plant.moisture}%", color = if (alert) Orange else Green, fontWeight = FontWeight.SemiBold)
            Text("Dernier arrosage : ${plant.lastAmountDl} dl · ${date(plant.lastWatered)}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable private fun BottomBar(selected: AppScreen, onSelect: (AppScreen) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        NavigationBarItem(selected = selected == AppScreen.HOME, onClick = { onSelect(AppScreen.HOME) }, icon = { Icon(Icons.Rounded.Home, null) }, label = { Text("Accueil") })
        NavigationBarItem(selected = selected == AppScreen.REMINDERS, onClick = { onSelect(AppScreen.REMINDERS) }, icon = { Icon(Icons.Rounded.Notifications, null) }, label = { Text("Rappels") })
        NavigationBarItem(selected = selected == AppScreen.SETTINGS, onClick = { onSelect(AppScreen.SETTINGS) }, icon = { Icon(Icons.Rounded.Settings, null) }, label = { Text("Réglages") })
    }
}

@Composable private fun RemindersScreen(plants: List<Plant>, modifier: Modifier = Modifier, onPlant: (Plant) -> Unit) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Rappels", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = DarkGreen); Text("Prochaines vérifications d’arrosage", color = Color.Gray) }
        lazyItems(plants.sortedBy { it.intervalDays - it.daysSinceWatered }) { plant ->
            val remaining = plant.intervalDays - plant.daysSinceWatered
            Card(Modifier.fillMaxWidth().clickable { onPlant(plant) }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (remaining <= 0) "💧" else "🌱", fontSize = 30.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) { Text(plant.name, fontWeight = FontWeight.Bold, color = DarkGreen); Text(if (remaining <= 0) "À vérifier aujourd’hui" else "Dans $remaining jour${if (remaining > 1) "s" else ""}", color = if (remaining <= 0) Orange else Green) }
                    Text("${plant.moisture}%", fontWeight = FontWeight.Bold, color = DarkGreen)
                }
            }
        }
        item { Text("Les dates sont des estimations basées sur vos arrosages. Vérifiez toujours la terre avant d’ajouter de l’eau.", fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp)) }
    }
}

@Composable private fun SettingsScreen(store: PlantStore, syncStatus: String, modifier: Modifier = Modifier) {
    var enabled by remember { mutableStateOf(store.notificationsEnabled()) }
    val context = LocalContext.current
    val sha1 = remember { signingSha1(context) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Réglages", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = DarkGreen); Text("Foyer Yanick & Jessica", color = Color.Gray) }
        item { FirebaseAccountCard() }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Notifications", fontWeight = FontWeight.Bold, color = DarkGreen); Text("Rappels quotidiens d’arrosage", color = Color.Gray, fontSize = 13.sp) }
                    Switch(checked = enabled, onCheckedChange = { enabled = it; store.setNotificationsEnabled(it) })
                }
            }
        }
        item { SettingCard("Unité d’arrosage", "Décilitres (dl)") }
        item { SettingCard("Synchronisation du foyer", syncStatus) }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Empreinte SHA-1", fontWeight = FontWeight.Bold, color = DarkGreen)
                    Text(sha1, color = Color.Gray, fontSize = 12.sp)
                    TextButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("SHA-1 PlantBot", sha1))
                    }) { Text("Copier l’empreinte") }
                }
            }
        }
        item {
            OutlinedButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            }, modifier = Modifier.fillMaxWidth()) { Text("Ouvrir les réglages Android des notifications") }
        }
        item { Text("Plant’Bot 0.4.4 · Signature permanente activée.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable private fun FirebaseAccountCard() {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var error by remember { mutableStateOf("") }
    val options = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(ch.yanick.plantbot.R.string.default_web_client_id))
            .requestEmail()
            .build()
    }
    val googleClient = remember { GoogleSignIn.getClient(context, options) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        GoogleSignIn.getSignedInAccountFromIntent(result.data)
            .addOnSuccessListener { account ->
                val credential = GoogleAuthProvider.getCredential(account.idToken, null)
                auth.signInWithCredential(credential).addOnCompleteListener { task ->
                    if (task.isSuccessful) { user = auth.currentUser; error = "" }
                    else error = task.exception?.localizedMessage ?: "Connexion impossible"
                }
            }
            .addOnFailureListener { error = it.localizedMessage ?: "Connexion Google annulée" }
    }
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text("Compte Google", fontWeight = FontWeight.Bold, color = DarkGreen)
            if (user == null) {
                Text("Connectez-vous pour préparer le partage avec Jessica.", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { launcher.launch(googleClient.signInIntent) }, modifier = Modifier.fillMaxWidth()) { Text("Se connecter avec Google") }
            } else {
                Text(user?.displayName ?: "Compte connecté", color = DarkGreen)
                Text(user?.email.orEmpty(), color = Color.Gray, fontSize = 13.sp)
                Text("Identifiant Firebase", fontWeight = FontWeight.SemiBold, color = DarkGreen, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Text(user?.uid.orEmpty(), color = Color.Gray, fontSize = 11.sp)
                TextButton(onClick = {
                    val uid = user?.uid.orEmpty()
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Identifiant Firebase PlantBot", uid))
                }) { Text("Copier l’identifiant") }
                TextButton(onClick = { auth.signOut(); googleClient.signOut(); user = null }) { Text("Se déconnecter") }
            }
            if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 12.sp)
        }
    }
}

@Composable private fun SettingCard(title: String, value: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) { Text(title, fontWeight = FontWeight.Bold, color = DarkGreen); Text(value, color = Color.Gray, fontSize = 13.sp) }
    }
}

@Composable private fun PlantDetailsDialog(
    plant: Plant,
    onDismiss: () -> Unit,
    onWater: () -> Unit,
    onSave: (Plant) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var name by remember(plant.id) { mutableStateOf(plant.name) }
    var species by remember(plant.id) { mutableStateOf(plant.species) }
    var description by remember(plant.id) { mutableStateOf(plant.description) }
    var days by remember(plant.id) { mutableFloatStateOf(plant.intervalDays.toFloat()) }
    var photoUri by remember(plant.id) { mutableStateOf(plant.photoUri) }
    var confirmDelete by remember { mutableStateOf(false) }
    var aiLoading by remember { mutableStateOf(false) }
    var aiError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photoUri = imageToDataUri(context, it) ?: it.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Fiche de la plante") },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                Box(
                    Modifier.size(150.dp).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(22.dp)).background(SoftGreen).clickable { photoPicker.launch(arrayOf("image/*")) },
                    contentAlignment = Alignment.Center
                ) {
                    if (photoUri.isNotBlank()) PlantPhoto(photoUri, "Photo de $name", Modifier.fillMaxSize())
                    else Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("📷", fontSize = 38.sp); Text("Ajouter une photo", fontSize = 12.sp) }
                }
                TextButton(onClick = { photoPicker.launch(arrayOf("image/*")) }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Choisir une photo") }
                if (photoUri.isNotBlank()) TextButton(onClick = { photoUri = "" }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Supprimer la photo") }
                OutlinedTextField(name, { name = it }, label = { Text("Nom") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(species, { species = it }, label = { Text("Espèce") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(description, { description = it }, label = { Text("Description et conseils") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedButton(
                    enabled = !aiLoading && (name.isNotBlank() || species.isNotBlank()),
                    onClick = {
                        aiLoading = true
                        aiError = ""
                        scope.launch {
                            runCatching {
                                val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                                    .generativeModel("gemini-3.8-flash")
                                val plantName = name.trim().ifBlank { species.trim() }
                                val plantSpecies = species.trim().ifBlank { plantName }
                                val existing = description.trim().takeIf { it.isNotBlank() }
                                val prompt = """
                                    Tu es un spécialiste prudent des plantes d'intérieur en Suisse.
                                    Rédige en français une fiche pratique, claire et concise pour cette plante :
                                    - Nom donné : $plantName
                                    - Espèce indiquée : $plantSpecies
                                    - Emplacement habituel : près d'une fenêtre avec voilage fin, sans soleil direct, à 21-22 °C
                                    - Fréquence de vérification actuelle : tous les ${days.toInt()} jours
                                    ${existing?.let { "- Description actuelle à améliorer : $it" } ?: ""}

                                    Donne 4 petites rubriques : Lumière, Arrosage, Température et humidité, Points de vigilance.
                                    Indique les signes de manque et d'excès d'eau, et précise la toxicité connue pour les humains ou animaux.
                                    N'invente pas l'identification : si l'espèce est incertaine, signale-le simplement.
                                    Ne donne pas de calendrier d'arrosage rigide et rappelle de vérifier le terreau.
                                    Maximum 170 mots, sans introduction ni conclusion.
                                """.trimIndent()
                                model.generateContent(prompt).text?.trim()
                                    ?.takeIf { it.isNotBlank() }
                                    ?: error("Réponse vide")
                            }.onSuccess { description = it }
                                .onFailure {
                                    aiError = "L’IA n’a pas pu répondre. Vérifiez Internet et réessayez."
                                }
                            aiLoading = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (aiLoading) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("PlantBot réfléchit…")
                    } else Text("✨ Compléter avec l’IA")
                }
                if (aiError.isNotBlank()) Text(aiError, fontSize = 12.sp, color = Color(0xFFB3261E))
                Spacer(Modifier.height(5.dp))
                Text("Vérifier tous les ${days.toInt()} jours", color = DarkGreen)
                Slider(days, { days = it }, valueRange = 2f..21f, steps = 18)
                Button(onClick = onWater, modifier = Modifier.fillMaxWidth()) { Text("J’ai arrosé") }
                TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFB3261E))) { Text("Supprimer cette plante") }
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank(), onClick = { onSave(plant.copy(name = name.trim(), species = species.trim().ifBlank { name.trim() }, intervalDays = days.toInt(), photoUri = photoUri, description = description.trim())); onDismiss() }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer ${plant.name} ?") },
        text = { Text("La plante et son historique d’arrosage seront supprimés de ce téléphone.") },
        confirmButton = { Button(onClick = onDelete, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))) { Text("Supprimer") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Annuler") } }
    )
}

@Composable private fun WaterDialog(plant: Plant, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var amount by remember { mutableFloatStateOf((plant.lastAmountDl.takeIf { it > 0 } ?: 3).toFloat()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Arroser ${plant.name}") }, text = { Column { Text("Quelle quantité avez-vous donnée ?"); Spacer(Modifier.height(14.dp)); Text("${amount.toInt()} dl", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green); Slider(amount, { amount = it }, valueRange = 1f..15f, steps = 13); Text("L’humidité affichée reste une estimation, sans capteur dans le pot.", fontSize = 12.sp, color = Color.Gray) } }, confirmButton = { Button(onClick = { onConfirm(amount.toInt()) }) { Text("Enregistrer") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } })
}

@Composable private fun AddPlantDialog(onDismiss: () -> Unit, onAdd: (String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }; var species by remember { mutableStateOf("") }; var days by remember { mutableFloatStateOf(7f) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Ajouter une plante") }, text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Nom") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(species, { species = it }, label = { Text("Espèce") }); Spacer(Modifier.height(12.dp)); Text("Vérifier tous les ${days.toInt()} jours"); Slider(days, { days = it }, valueRange = 2f..21f, steps = 18) } }, confirmButton = { Button(enabled = name.isNotBlank(), onClick = { onAdd(name, species.ifBlank { name }, days.toInt()) }) { Text("Ajouter") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } })
}

private fun date(timestamp: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(Date(timestamp))

private fun signingSha1(context: Context): String = runCatching {
    val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
    val certificate = info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray() ?: return@runCatching "Indisponible"
    MessageDigest.getInstance("SHA-1").digest(certificate).joinToString(":") { "%02X".format(it) }
}.getOrDefault("Indisponible")

private fun imageToDataUri(context: Context, uri: Uri): String? = runCatching {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@runCatching null
    val original = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@runCatching null
    val maxSide = 640
    val scale = minOf(1f, maxSide.toFloat() / maxOf(original.width, original.height))
    val resized = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(
        original,
        (original.width * scale).toInt().coerceAtLeast(1),
        (original.height * scale).toInt().coerceAtLeast(1),
        true
    ) else original
    val output = ByteArrayOutputStream()
    resized.compress(android.graphics.Bitmap.CompressFormat.JPEG, 68, output)
    if (resized !== original) resized.recycle()
    original.recycle()
    "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
}.getOrNull()

@Composable
private fun PlantPhoto(source: String, description: String, modifier: Modifier = Modifier) {
    if (source.startsWith("data:image/")) {
        val bitmap = remember(source) {
            runCatching {
                val bytes = Base64.decode(source.substringAfter(','), Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()
        }
        if (bitmap != null) Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = description,
            modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
    } else {
        AsyncImage(
            model = source,
            contentDescription = description,
            modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop
        )
    }
}
