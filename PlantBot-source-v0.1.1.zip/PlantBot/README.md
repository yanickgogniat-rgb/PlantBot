# Plant’Bot

Application Android de gestion partagée des plantes de Yanick et Jessica.

## Version 0.1

- interface responsive pour écran externe et grand écran pliable ;
- robot animé et humidité clairement indiquée comme estimation ;
- fiches préchargées pour les plantes du foyer ;
- saisie des arrosages en décilitres et historique local ;
- ajout de plantes et rappels Android quotidiens ;
- compilation automatique de l’APK avec GitHub Actions.

La synchronisation Firebase et la connexion Google seront activées après ajout privé de `app/google-services.json`.
