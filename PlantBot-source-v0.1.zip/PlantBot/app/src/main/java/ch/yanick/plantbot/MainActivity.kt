package ch.yanick.plantbot

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Green = Color(0xFF188A68)
private val DarkGreen = Color(0xFF103C32)
private val Cream = Color(0xFFF6F7F0)
private val SoftGreen = Color(0xFFDCEEDB)
private val Orange = Color(0xFFFF6B35)

data class Plant(
    val id: Long,
    val name: String,
    val species: String,
    val intervalDays: Int,
    val lastWatered: Long,
    val lastAmountDl: Int
) {
    val daysSinceWatered: Int get() = ((System.currentTimeMillis() - lastWatered) / 86_400_000L).toInt().coerceAtLeast(0)
    val moisture: Int get() = (100 - daysSinceWatered * (100 / intervalDays.coerceAtLeast(1))).coerceIn(0, 100)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        scheduleChecks()
        setContent { PlantBotApp(PlantStore(this)) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("watering", "Rappels d’arrosage", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    private fun scheduleChecks() {
        val request = PeriodicWorkRequestBuilder<WateringWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("plant-check", ExistingPeriodicWorkPolicy.KEEP, request)
    }
}

class WateringWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val due = PlantStore(applicationContext).load().filter { it.daysSinceWatered >= it.intervalDays }
        if (due.isNotEmpty()) {
            val notification = NotificationCompat.Builder(applicationContext, "watering")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Plant’Bot a besoin de toi 💧")
                .setContentText("${due.first().name} est à vérifier${if (due.size > 1) " et ${due.size - 1} autre(s) plante(s)" else ""}.")
                .setAutoCancel(true)
                .build()
            applicationContext.getSystemService(NotificationManager::class.java).notify(1001, notification)
        }
        return Result.success()
    }
}

class PlantStore(context: Context) {
    private val prefs = context.getSharedPreferences("plants", Context.MODE_PRIVATE)
    fun load(): List<Plant> {
        val raw = prefs.getString("items", null) ?: return defaults().also(::save)
        return runCatching {
            val array = JSONArray(raw)
            List(array.length()) { i ->
                val o = array.getJSONObject(i)
                Plant(o.getLong("id"), o.getString("name"), o.optString("species"), o.getInt("interval"), o.getLong("watered"), o.getInt("amount"))
            }
        }.getOrElse { defaults() }
    }
    fun save(plants: List<Plant>) {
        val a = JSONArray()
        plants.forEach { p -> a.put(JSONObject().apply {
            put("id", p.id); put("name", p.name); put("species", p.species); put("interval", p.intervalDays)
            put("watered", p.lastWatered); put("amount", p.lastAmountDl)
        }) }
        prefs.edit().putString("items", a.toString()).apply()
    }
    private fun defaults(): List<Plant> {
        val now = System.currentTimeMillis()
        return listOf(
            Plant(1, "Alocasia", "Alocasia", 6, now - 5 * 86_400_000L, 3),
            Plant(2, "Caladium", "Caladium bicolor", 4, now - 2 * 86_400_000L, 3),
            Plant(3, "Aglaonema argenté", "Aglaonema", 8, now - 3 * 86_400_000L, 3),
            Plant(4, "Croton ‘Iceton’", "Codiaeum variegatum", 6, now - 3 * 86_400_000L, 3),
            Plant(5, "Euphorbia platyclada", "Euphorbia", 14, now - 7 * 86_400_000L, 2)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlantBotApp(store: PlantStore) {
    var plants by remember { mutableStateOf(store.load()) }
    var watering by remember { mutableStateOf<Plant?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Cream, surface = Color.White, onBackground = DarkGreen)) {
        Scaffold(
            containerColor = Cream,
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Color.White) { Icon(Icons.Rounded.Add, "Ajouter") } },
            bottomBar = { BottomBar() }
        ) { padding ->
            BoxWithConstraints(Modifier.padding(padding).fillMaxSize()) {
                val columns = if (maxWidth >= 600.dp) 2 else 1
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    contentPadding = PaddingValues(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) { Header() }
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) {
                        val priority = plants.minByOrNull { it.moisture }
                        RobotCard(priority, onWater = { priority?.let { watering = it } })
                    }
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(columns) }) {
                        Text("Mes plantes", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkGreen, modifier = Modifier.padding(top = 8.dp))
                    }
                    items(plants, key = { it.id }) { plant -> PlantCard(plant) { watering = plant } }
                }
            }
        }
        watering?.let { plant -> WaterDialog(plant, onDismiss = { watering = null }) { amount ->
            plants = plants.map { if (it.id == plant.id) it.copy(lastWatered = System.currentTimeMillis(), lastAmountDl = amount) else it }
            store.save(plants); watering = null
        } }
        if (showAdd) AddPlantDialog(onDismiss = { showAdd = false }) { name, species, days ->
            plants = plants + Plant(System.currentTimeMillis(), name, species, days, System.currentTimeMillis(), 0)
            store.save(plants); showAdd = false
        }
    }
}

@Composable private fun Header() {
    Column { Text("Plant’Bot", color = Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); Text("Bonjour Yanick 👋", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = DarkGreen); Text("Comment vont vos plantes ?", color = Color(0xFF52625D), fontSize = 17.sp) }
}

@Composable private fun RobotCard(priority: Plant?, onWater: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "robot")
    val bob by transition.animateFloat(-5f, 5f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "bob")
    Card(colors = CardDefaults.cardColors(containerColor = SoftGreen), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(0.9f).graphicsLayer { translationY = bob }) {
                Box(Modifier.size(92.dp).clip(RoundedCornerShape(28.dp)).background(Color.White), contentAlignment = Alignment.Center) { Text("🤖", fontSize = 52.sp) }
                Text(if ((priority?.moisture ?: 100) < 30) "J’ai soif…" else "Tout va bien !", fontWeight = FontWeight.Bold, color = Green)
            }
            Column(Modifier.weight(1.2f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Humidité estimée", color = DarkGreen)
                Text("${priority?.moisture ?: 100} %", fontSize = 38.sp, fontWeight = FontWeight.Black, color = DarkGreen)
                Text(priority?.name ?: "Aucune plante", maxLines = 1, color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onWater, shape = RoundedCornerShape(18.dp)) { Text("J’ai arrosé") }
            }
        }
    }
}

@Composable private fun PlantCard(plant: Plant, onWater: () -> Unit) {
    val alert = plant.daysSinceWatered >= plant.intervalDays
    Card(onClick = onWater, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(if (alert) Color(0xFFFFE1D7) else SoftGreen), contentAlignment = Alignment.Center) { Text(if (alert) "🪴" else "🌿", fontSize = 29.sp) }
                Spacer(Modifier.width(12.dp)); Column { Text(plant.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = DarkGreen); Text(plant.species, fontSize = 13.sp, color = Color.Gray) }
            }
            Spacer(Modifier.height(15.dp)); LinearProgressIndicator(progress = { plant.moisture / 100f }, modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape), color = if (alert) Orange else Green, trackColor = Color(0xFFE8ECE8))
            Spacer(Modifier.height(9.dp)); Text(if (alert) "💧 À vérifier aujourd’hui" else "💧 Humidité estimée ${plant.moisture}%", color = if (alert) Orange else Green, fontWeight = FontWeight.SemiBold)
            Text("Dernier arrosage : ${plant.lastAmountDl} dl · ${date(plant.lastWatered)}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable private fun BottomBar() { NavigationBar(containerColor = Color.White) { NavigationBarItem(true, {}, { Icon(Icons.Rounded.Home, null) }, { Text("Accueil") }); NavigationBarItem(false, {}, { Icon(Icons.Rounded.Notifications, null) }, { Text("Rappels") }); NavigationBarItem(false, {}, { Icon(Icons.Rounded.Settings, null) }, { Text("Réglages") }) } }

@Composable private fun WaterDialog(plant: Plant, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    var amount by remember { mutableFloatStateOf((plant.lastAmountDl.takeIf { it > 0 } ?: 3).toFloat()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Arroser ${plant.name}") }, text = { Column { Text("Quelle quantité avez-vous donnée ?"); Spacer(Modifier.height(14.dp)); Text("${amount.toInt()} dl", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green); Slider(amount, { amount = it }, valueRange = 1f..15f, steps = 13); Text("L’humidité affichée reste une estimation, sans capteur dans le pot.", fontSize = 12.sp, color = Color.Gray) } }, confirmButton = { Button(onClick = { onConfirm(amount.toInt()) }) { Text("Enregistrer") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } })
}

@Composable private fun AddPlantDialog(onDismiss: () -> Unit, onAdd: (String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }; var species by remember { mutableStateOf("") }; var days by remember { mutableFloatStateOf(7f) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Ajouter une plante") }, text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Nom") }); Spacer(Modifier.height(8.dp)); OutlinedTextField(species, { species = it }, label = { Text("Espèce") }); Spacer(Modifier.height(12.dp)); Text("Vérifier tous les ${days.toInt()} jours"); Slider(days, { days = it }, valueRange = 2f..21f, steps = 18) } }, confirmButton = { Button(enabled = name.isNotBlank(), onClick = { onAdd(name, species.ifBlank { name }, days.toInt()) }) { Text("Ajouter") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } })
}

private fun date(timestamp: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.FRANCE).format(Date(timestamp))
